//
//  ViewController.h
//  ScanAnmation
//
//  Created by Augus on 2020/9/14.
//  Copyright © 2020 Fosafer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

