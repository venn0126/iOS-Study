//
//  SceneDelegate.h
//  ScanAnmation
//
//  Created by Augus on 2020/9/14.
//  Copyright © 2020 Fosafer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

