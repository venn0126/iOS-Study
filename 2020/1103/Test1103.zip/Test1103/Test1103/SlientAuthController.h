//
//  SlientAuthController.h
//  offFaceDemo
//
//  Created by Augus on 2020/2/24.
//  Copyright © 2020 fosafer. All rights reserved.
//

#import "ViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SlientAuthController : ViewController

@property (nonatomic,copy) NSString *userName;
@property (nonatomic,copy) NSString *groupName;

@end

NS_ASSUME_NONNULL_END
