//
//  SceneDelegate.h
//  Test1103
//
//  Created by Augus on 2020/11/3.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

