//
//  YMLine.h
//  IDCardDemo
//
//  Created by linmac on 16-10-15.
//  Copyright (c) 2013年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YMLine : NSObject

@property (assign, nonatomic) int allLine;
@property (assign, nonatomic) int leftLine;
@property (assign, nonatomic) int rightLine;
@property (assign, nonatomic) int topLine;
@property (assign, nonatomic) int bottomLine;

@end
