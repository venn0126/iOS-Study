//
//  FosaferAuth.h
//  FosaferAuth
//
//  Created by Wei Niu on 2017/8/3.
//  Copyright © 2017年 Fosafer. All rights reserved.
//


#import<FosaferAuth/FOSFosafer.h>
#import<FosaferAuth/FOSLogger.h>
#import<FosaferAuth/FOSAuthenticator.h>
#import<FosaferAuth/FOSFaceModeler.h>
#import<FosaferAuth/FOSSpeakerModeler.h>
#import<FosaferAuth/FOSNoiseDetector.h>
#import<FosaferAuth/FOSCompareTool.h>
#import<FosaferAuth/FOSSpeechRecognizer.h>



