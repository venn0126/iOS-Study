
__attribute__((section(("__HIB,__text"))))
int _start() {
	return 0;
}