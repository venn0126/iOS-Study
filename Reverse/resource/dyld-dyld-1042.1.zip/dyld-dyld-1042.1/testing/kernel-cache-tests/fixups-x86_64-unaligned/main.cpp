
__attribute__((section(("__HIB, __text"))))
extern "C" int _start() {
	return 0;
}