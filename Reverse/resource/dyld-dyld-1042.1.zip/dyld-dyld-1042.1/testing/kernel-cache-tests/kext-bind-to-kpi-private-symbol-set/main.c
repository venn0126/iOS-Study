
int _start() {
	return 0;
}

int foo() {
	return 0;
}