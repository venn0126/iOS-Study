
int x;
int *p = &x;

int _start() {
	return *p;
}