

extern "C" int _start() {
	return 0;
}