
// We need this symbol to bind missing weak imports to
int gOSKextUnresolved = 0;

int _start() {
	return 0;
}