
int x = 0;
int* g = &x;

int _start() {
	return *g;
}