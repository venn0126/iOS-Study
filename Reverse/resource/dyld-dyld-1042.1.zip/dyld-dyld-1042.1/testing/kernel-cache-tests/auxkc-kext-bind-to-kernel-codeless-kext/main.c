
// This will be re-exported from a symbol set in bar
int symbol_from_xnu() {
	return 0;
}

int _start() {
	return 0;
}