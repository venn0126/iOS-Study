

#include "metaclass.h"

class OSObject : public OSMetaClassBase
{
	OSDeclareAbstractStructorsWithDispatch(OSObject);
};
