local jwt = require "resty.jwt"
local cjson = require "cjson"
local rep = require "response_body"

local cid = nil
local cret = nil

function split(str,reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function ( w )
        table.insert(resultStrList,w)
    end)
    return resultStrList
end
--local request_method = ngx.var.request_method
--if 'POST' == request_method then
  -- ngx.req.read_body()
   
   data = ngx.req.get_body_data()
   if data == nil then
       rep.response("10003","传入参数为非法")
       return
   end
   local tab = split(data,"&")
        
   for k, v in pairs(tab) do
      local suc,temp_tab = pcall(cjson.decode,v)   
      if suc then
         if temp_tab["client_id"] then
            cid = temp_tab["client_id"]
          end
      
          if temp_tab["client_secret"] then
             cret = temp_tab["client_secret"]
           end
      else
          rep.response("10006","参数解析失败")
          return
      end
   end


if cid == nil or cid == "" then
   rep.response("10003","缺少client_id参数")
   return  
end

if cret == nil or cret == "" then
   rep.response("10003","缺少client_secret参数")
   return
end

-- cid and cc check legal

local tab = "myhash"
local redis = require "resty.redis"
local red = redis:new()
red:set_timeout(1000)
local ok, err = red:connect("127.0.0.1", 6379)
if not ok then
   rep.response("10004",err)
   return
end

local res, err = red:hmget(tab,cid)
if not res then
   rep.response("10004",err)
   return
end

if res[1] == ngx.null or res[1] == "" then
   rep.response("10005","商户不存在")
   return
end

local ok, data = pcall(cjson.decode,res[1])
if not ok then
   rep.response("10006","json decode err")
   return
end

local value = ""
if type(data) == 'number' then
    value = tostring(data)
elseif type(data) == 'table' then
     if data.merchant_no == nil or data.merchant_no == "" then
        rep.response("10003","merchant_no不存在")
        return
    end
   value = data.merchant_no
end

if cid ~= value then
   rep.response("10003","商户校验失败")
   return
end

local value1 = ""
if type(data) == 'number' then
    value1 = tostring(data)
elseif type(data) == 'table' then
     if data.cc == nil or data.cc == "" then
        rep.response("10003","cc不存在")
        return
    end
   value1 = data.cc
end

if cret ~= value1 then
   rep.response("10003","cc校验失败")
   return
end

-- gen token
local cur_stmp = os.time()
-- 有效时长 2 * 60 * 60
local exp_stmp = 7200 * 1000 + cur_stmp
-- 密钥固定 与 auth 一致
local secret = "www.fosafer.com"
local jwt_token = jwt:sign(
                   secret,
                    {
                        header={typ="JWT", alg="HS256"},
                        payload={clientId=cid,isss="fosafer.com",iat=cur_stmp,exp=exp_stmp}
                    }
                )
--ngx.say(jwt_token)
--ngx.say(cid..cret)
if jwt_token then
   local resp = {}
   resp["code"] = 0
   resp["access_token"] = jwt_token
   resp["token_type"] = "Bearer"
   resp["expires_in"] = 7200
   ngx.say(cjson.encode(resp))
   return resp
else
   rep.response("0","token获取失败，请重试")
   return
end
