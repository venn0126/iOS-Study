local jwt = require "resty.jwt"
local cjson = require "cjson"
--local mysplit = require "my-split"
--local my64 = require "fbase64"

--your secret
local secret = "www.fosafer.com"

local M = {}

function M.auth(claim_specs)
    -- require Authorization request header
    local auth_header = ngx.req.get_headers().Authorization
    local p_info = ngx.req.get_headers().product_info
    local c_id = ngx.req.get_headers().contract_id
    --ngx.say(auth_header)
    if auth_header == nil then
        ngx.log(ngx.WARN, "No Authorization header")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end

    if p_info == nil then
        ngx.log(ngx.WARN, "No product_info  header")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end
    ngx.var.product_info = p_info

    if c_id == nil then
        ngx.log(ngx.WARN, "No contract_id  header")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end
    ngx.var.contract_id = c_id
    -- ngx.log(ngx.INFO, "Authorization: " .. auth_header)

    local _, _, token = string.find(auth_header, "Bearer%s+(.+)")
    --ngx.say(token)
    if token == nil then
        ngx.log(ngx.WARN, "Missing token")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end


    --ngx.log(ngx.INFO, "Token: " .. token)
    --[[
    -- get middle base64 encode str
    local sub_tab = mysplit.split(token,".")
    local mid_str = sub_tab[2]
    if mid_str == nil then
        ngx.log(ngx.WARN,"miss middle token")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end
    
    -- base 64 decode === encode
    local str_dec = my64.base64decode(mid_str)
    -- json str to map
    local tab = cjson.decode(str_dec)
    local cid = tab["clientId"]
    if cid == nil then
        ngx.log(ngx.WARN,"miss client id")
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end
    -- write the cid variable
    ngx.var.cid = cid
    --ngx.say(cid)
   
]]-- 
    local jwt_obj = jwt:verify(secret, token)
    --ngx.say(jwt_obj.verified)
    if jwt_obj.verified == false then
        ngx.log(ngx.ERR, "Invalid token: ".. jwt_obj.reason)
        ngx.exit(ngx.HTTP_UNAUTHORIZED)
    end

    ngx.log(ngx.ERR, "JWT: " .. cjson.encode(jwt_obj))
    -- write the uid variable
    ngx.var.merchant_no = jwt_obj.payload.clientId
    --ngx.say(ngx.var.cid)
end

return M
