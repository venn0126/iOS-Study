//
//  APFaceFacade.h
//  APFaceDetectBiz
//
//  Created by 晗羽 on 8/25/16.
//  Copyright © 2016 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BioAuthEngine/IBioAuthFactor.h>

@interface APBToygerFacade : NSObject <IBioAuthFactor>

@end
