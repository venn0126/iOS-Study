//
//  APBSystem.h
//  BioAuthService
//
//  Created by yukun.tyk on 12/14/15.
//  Copyright © 2015 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface APBSystem : NSObject

+ (double)systemVer;

+ (NSString *)modelString;


@end
