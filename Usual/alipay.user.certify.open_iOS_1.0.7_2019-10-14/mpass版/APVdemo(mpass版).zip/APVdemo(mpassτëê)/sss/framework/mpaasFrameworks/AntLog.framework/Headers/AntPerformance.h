//
//  AntPerformance.h
//  APRemoteLogging
//
//  Created by 卡迩 on 2017/1/15.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#ifndef WIP
#import "AntLogEvent.h"

/**
 性能日志模型
 */
@interface AntPerformance : AntLogEvent

//TODO: IMP
@property (nonatomic, copy) NSString *todo;

@end
#endif
