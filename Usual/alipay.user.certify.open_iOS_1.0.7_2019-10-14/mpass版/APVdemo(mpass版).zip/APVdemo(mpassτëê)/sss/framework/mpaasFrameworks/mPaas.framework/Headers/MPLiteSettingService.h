//
//  MPLiteSettingService.h
//  mPaas
//
//  Created by shenmo on 6/3/16.
//  Copyright © 2016 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MPLiteSettingService : NSObject

@end
