//
//  ALPesistenceStore.h
//  APRemoteLogging
//
//  Created by 卡迩 on 2017/1/16.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#ifndef WIP
#ifndef AntLogPesistenceStore_h
#define AntLogPesistenceStore_h


/**
 AntLog持久化存储接口.
 用于内部持久化缓存配置信息、开关信息.
 默认有一个NSUserDefault的实现.
 接入方需要自定义实现时,可以使用AntLogPersistenceStoreClass(name)宏指定类名.
 */
@protocol AntLogPersistenceStore <NSObject>

@required
/**
 生成一个 AntLogPersistenceStore 实例
 */
+ (id<AntLogPersistenceStore>)instance;

/**
 获取 \c key 对应的对象.

 @param key 对象存储时使用的唯一key.
 @return 存在\c key 对应的对象时返回该对象. 否则返回 \c nil.
 */
- (id)getObjectForKey:(NSString *)key;

/**
 保存一个对象到持久化缓存中.

 @param obj 待保存对象
 @param key 对象存储时的唯一key
 @return 成功返回 \c YES，否则返回 \c NO.
 */
- (BOOL)saveObject:(id)obj
            forKey:(NSString *)key;

@end

#ifndef AntLogStore
#define AntLogStore AntLogPersistenceStoreGet()
#endif

#ifdef __cplusplus
extern "C"{
#endif
    
    id<AntLogPersistenceStore> AntLogPersistenceStoreGet();
    
#ifdef __cplusplus
}
#endif

#endif /* ALPesistenceStore_h */
#endif //WIP
