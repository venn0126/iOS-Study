//
//  AntLog.h
//  APRemoteLogging
//
//  Created by 卡迩 on 2017/1/12.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#ifndef WIP
#import "AntLogger.h"
#import "AntLogMessage.h"
#import "AntBehavior.h"
#import "AntPerformance.h"
#import "AntLogFormatter.h"
#import "AntLogUploader.h"

@interface AntLog : NSObject

/**
 获取 \c AntLog单例.
 
 @return \c AntLog 单例.
 */
+ (AntLog *)sharedInstance;

/**
 输出一条行为日志

 @param behavior 行为日志对象
 */
+ (void)logBehavior:(AntBehavior *)behavior;

/**
 输出一条性能日志

 @param performance 性能日志对象
 */
+ (void)logPerformance:(AntPerformance *)performance;

/**
 输出一条行为日志

 @param actionId 行为日志中的ActionId
 @param extParams 扩展参数
 @param appId 子应用Id
 @param seed seedId
 @param ucId 用例Id
 @param bizType 业务类型
 @param extInfo 其他参数Key-Value对
 */
+ (void)logWithActionId:(NSString *)actionId
              extParams:(NSArray *)extParams
                  appId:(NSString *)appId
                   seed:(NSString *)seed
                   ucId:(NSString *)ucId
                bizType:(NSString *)bizType
                extInfo:(NSDictionary *)extInfo;

/**
 输出一条性能日志

 @param type 性能日志类型
 @param subType 子类型
 */
+ (void)performanceLogWithType:(NSString *)type
                       subType:(NSString *)subType;


/**
 输出一条本地日志

 @param msg 日志内容对象
 */
+ (void)localLog:(AntLogMessage *)msg;

@end
#endif //WIP
