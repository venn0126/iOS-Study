//
//  AntLogLevel.h
//  AntLog
//
//  Created by 卡迩 on 2017/1/28.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#ifndef WIP
#ifndef AntLogLevel_h
#define AntLogLevel_h

typedef NS_ENUM(NSUInteger,AntLogLevel) {
    AntLogLevelError = 0, //级别最高
    AntLogLevelHigh,
    AntLogLevelNormal,
    AntLogLevelLow        //级别最低
};

#endif /* AntLogLevel_h */
#endif
