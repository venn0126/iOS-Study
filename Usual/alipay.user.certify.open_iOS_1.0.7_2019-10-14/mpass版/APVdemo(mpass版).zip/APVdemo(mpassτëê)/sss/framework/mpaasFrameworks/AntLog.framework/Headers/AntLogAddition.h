//
//  AntLogAddition.h
//  AntLog
//
//  Created by 卡迩 on 2017/2/9.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#ifndef WIP

#import <Foundation/Foundation.h>
#import "AntLogAdditionInfoProvider.h"


/**
 AntLogAdditionInfoProvider 的默认实现,若接入方想自定义其中的字段,
 可以子类化并通过AntLogContext接口设置.
 */
@interface AntLogAddition : NSObject<AntLogAdditionInfoProvider>

@end

#endif //WIP
