//
//  MPaaS+ImportMPLiteSettingService.h
//  APMPaaS
//
//  Created by shenmo on 8/29/16.
//  Copyright © 2016 Alipay. All rights reserved.
//

#import "MPLiteSettingService+MPaaS.h"

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus
    
    id<MPLiteSettingServiceClass> getMPLiteSettingService();
    
#ifdef __cplusplus
}
#endif // __cplusplus