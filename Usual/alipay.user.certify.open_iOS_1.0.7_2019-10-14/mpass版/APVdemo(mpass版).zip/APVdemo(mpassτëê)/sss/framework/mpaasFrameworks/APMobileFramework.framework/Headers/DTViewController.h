//
//  DTViewController.h
//  MPMobileFramework
//
//  Created by shenmo on 1/6/16.
//  Copyright © 2016 shenmo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DTBaseViewController.h"

@interface DTViewController : DTBaseViewController

@end
