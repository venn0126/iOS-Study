//
//  ZolozMobileInterceptor.m
//  MTPotal
//
//  Created by zhangmin on 2018/3/5.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <APMobileNetwork/APMobileNetwork.h>

@interface ZolozMobileInterceptor : NSObject <DTRpcInterceptor>

@end
