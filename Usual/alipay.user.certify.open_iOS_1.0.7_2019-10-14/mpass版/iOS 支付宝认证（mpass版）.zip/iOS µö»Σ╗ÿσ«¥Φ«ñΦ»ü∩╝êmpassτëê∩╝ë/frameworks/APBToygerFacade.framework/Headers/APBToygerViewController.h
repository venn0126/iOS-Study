//
//  APFViewController.h
//  APFaceDetectBiz
//
//  Created by 晗羽 on 8/25/16.
//  Copyright © 2016 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APBToygerViewController : UIViewController
-(void)setStatusBarBackgroundColor:(UIColor *)color;
@end
