//
//  ZolozOpenPlatformBuild.h
//  ZolozOpenPlatformBuild
//
//  Created by richard on 26/02/2018.
//  Copyright © 2018 com.alipay.iphoneclient.zoloz. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZolozOpenPlatformBuild.
FOUNDATION_EXPORT double ZolozOpenPlatformBuildVersionNumber;

//! Project version string for ZolozOpenPlatformBuild.
FOUNDATION_EXPORT const unsigned char ZolozOpenPlatformBuildVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZolozOpenPlatformBuild/PublicHeader.h>


