//
//  MPAnalysis.h
//  MPAnalysis
//
//  Created by yangwei on 16/12/8.
//  Copyright © 2016年 Alipay. All rights reserved.
//

#ifndef MPAnalysis_h
#define MPAnalysis_h

#import "MPAnalysisHelper.h"
#import "MPAnalysisInterface.h"

#endif /* MPAnalysis_h */
