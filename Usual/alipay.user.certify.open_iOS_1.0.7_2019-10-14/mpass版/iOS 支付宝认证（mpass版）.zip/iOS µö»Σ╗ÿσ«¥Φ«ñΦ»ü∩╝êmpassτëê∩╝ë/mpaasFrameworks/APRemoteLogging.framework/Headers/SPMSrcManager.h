//
//  SPMSrcManager.h
//  SPMTracker
//
//  Created by BoTao on 2017/4/26.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPMSrcManager : NSObject

// 获取钱包内最后一次点击的spmid
+ (NSString *)lastClickedSpmId;

// 更新当前vc的最后一次点击spmid
+ (void)updateClickedSpm:(NSString *)spmId vc:(NSObject *)vc;

// 根据vc获取点击spm数据
+ (NSString *)getClickedSpmInfoWithVC:(NSObject *)vc;

// 根据vc获取初始的点击spm数据，10.0.15版本临时使用，用于pagemonitor refer
+ (NSString *)getFirstClickedSpmInfoWithVC:(NSObject *)vc;

// 根据vc删除记录
+ (void)removeRecordWithVC:(NSObject *)vc;

@end
