//
//  AntLogger.h
//  APRemoteLogging
//
//  Created by 卡迩 on 2017/1/12.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#ifndef WIP
#ifndef AntLogger_h
#define AntLogger_h

#import "AntLogFormatter.h"
#import "AntLogEvent.h"
/**
 Logger接口
 */
@protocol AntLogger <NSObject>

/**
 输出一条日志消息.

 @param msg 日志消息对象
 */
- (void)logEvent:(AntLogEvent *)event;

/**
 日志格式化Formatter. @see \c AntLogFormatter
 */
@property (nonatomic, strong) id <AntLogFormatter> logFormatter;

@end

#endif /* AntLogger_h */
#endif //WIP
