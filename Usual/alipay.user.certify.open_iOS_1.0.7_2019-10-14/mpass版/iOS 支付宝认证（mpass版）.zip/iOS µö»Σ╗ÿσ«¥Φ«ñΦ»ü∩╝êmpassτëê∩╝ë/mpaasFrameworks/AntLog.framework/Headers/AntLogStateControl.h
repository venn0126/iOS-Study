//
//  AntLogStateControl.h
//  AntLog
//
//  Created by 卡迩 on 2017/2/28.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#ifndef WIP
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 AntLog中的全局页面、点击状态信息维护类.
 部分信息需要上层业务模块在特定时机调用该类的接口来实现更新.
 */
@interface AntLogStateControl : NSObject

#pragma mark - Singleton

/**
 获取全局状态维护器实例.

 @return 全局状态维护器实例.
 */
+ (AntLogStateControl *)shared;

#pragma mark - ActionControl
/**
 更新全局的ActionControl信息.

 @param newId 新的ActionControlID
 @param desc  新的ActionControlDesc
 */
- (void)onCurrentActionControlIdChanged:(NSString *)newId
                             actionDesc:(NSString *)desc;

#pragma mark - PageInfo
/**
 更新全局的当前ViewId信息.
 @note 调用该方法同时会修改上一个页面ID的值(lastViewID)

 @param newPageId 新的PageId
 */
- (void)onCurrentPageChanged:(NSString *)newViewId
                       appId:(NSString *)appId
                 sourceAppId:(NSString *)sourceAppId
                    pageName:(NSString *)pageName;

#pragma mark - Refer
/**
 更新全局的refer信息.
 @note 该方法默认会在AutoTracker中一个VC消失时调用.

 @param refer 新的refer内容.
 */
- (void)onReferChanged:(NSString *)refer;

#pragma mark - PageMonitor
/**
 兼容老版本的pageMonitor.
 在调用pageStart时,会记录一个页面信息,但不会真正落日志;
 在调用pageEnd时,会使用pageStart时记录的信息落一条actionID = pageMonitor的日志.
 @note pageMonitor方法的调用不会修改全局当前页面.
 */

- (void)onPageStartWithSpmId:(NSString *)spmId
                        page:(id<NSObject>)pageIndex;

- (void)onPageEndWithSpmId:(NSString *)spmId
                      page:(id<NSObject>)pageIndex
                   bizType:(NSString *)bizType
                     param:(NSDictionary *)param;

- (nullable NSString *)getMiniPageIdForIndex:(id<NSObject>)pageIndex;

@end
NS_ASSUME_NONNULL_END
#endif //WIP
