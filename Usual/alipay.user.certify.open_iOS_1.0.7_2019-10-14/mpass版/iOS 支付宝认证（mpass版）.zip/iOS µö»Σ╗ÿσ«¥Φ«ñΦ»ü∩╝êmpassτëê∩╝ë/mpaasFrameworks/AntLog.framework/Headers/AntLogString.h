//
//  AntLogStringBuilder.h
//  AntLog
//
//  Created by 卡迩 on 2017/3/13.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#ifndef WIP
#import <Foundation/Foundation.h>

/**
 日志字符串Builder类.
 内部封装了一个C++的std::string用于处理字符串append、特殊字符过滤逻辑.
 */
@interface AntLogString : NSObject

/**
 添加一个字段.
 对于 \c nil 值或空字符串,会以占位符添加.多个字段之间会自动添加分隔符.
 @param fieldValue 字段值.
 @return 添加fieldValue后的字符串Builder对象.
 */
- (nonnull AntLogString *)addField:(nullable NSString *)fieldValue;

- (nonnull AntLogString *)addField:(nullable NSString *)fieldValue
                              last:(BOOL)last;

/**
 完成构建.
 该方法调用时会在字符串末尾添加结束符.该方法只能调用一次,多次调用会抛异常.

 @return 完成构建后的字符串Builder对象.
 */
- (nonnull AntLogString *)build;

/**
 获取当前字符串内容的长度.
 
 @return 当前字符串内容的长度.
 */
- (NSUInteger)length;

/**
 获取utf8形式的字符串内容.

 @return utf8形式的字符串内容
 */
- (nullable const char *)utf8String;

/**
 获取NSString形式的字符串内容.

 @return NSString形式的字符串内容
 */
- (nullable NSString *)string;

@end
#endif //WIP
