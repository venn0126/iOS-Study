//
//  AntLogUploader.h
//  APRemoteLogging
//
//  Created by 卡迩 on 2017/1/12.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#ifndef AntLogUploader_h
#define AntLogUploader_h
/**
 日志上传接口
 */
@protocol AntLogUploader <NSObject>

@required
/**
 上传日志内容

 @param package 待上传的日志内容二进制,未压缩、加密
 @param bizType 日志的业务类型
 @param completionBlock 结果回调.
 */
-(void)uploadData:(NSData *)package
          bizType:(NSString *)bizType
              url:(NSString *)url
  completionBlock:(void (^) (BOOL success))completionBlock;

@end

#endif /* AntLogUploader_h */
