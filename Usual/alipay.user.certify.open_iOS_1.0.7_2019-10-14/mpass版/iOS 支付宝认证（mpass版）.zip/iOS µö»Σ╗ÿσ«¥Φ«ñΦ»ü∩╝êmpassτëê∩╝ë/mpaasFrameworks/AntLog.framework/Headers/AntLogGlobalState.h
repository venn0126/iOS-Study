//
//  AntLogGlobalState.h
//  AntLog
//
//  Created by 卡迩 on 2017/1/28.
//  Copyright © 2017年 Alipay. All rights reserved.
//
#ifndef WIP
#import <Foundation/Foundation.h>

@interface AntLogGlobalState : NSObject

@property (nonatomic, copy) NSString *curSubAppId;
@property (nonatomic, copy) NSString *curSourceSubAppId;
@property (nonatomic, copy) NSString *curViewId;
@property (nonatomic, copy) NSString *curPageName;
@property (nonatomic, copy) NSString *lastViewId;
@property (nonatomic, copy) NSString *lastPageName;

/**
 当前页面的来源流转信息.内容为"前一个页面的spmId|前一个页面的pageId".
 */
@property (nonatomic, copy) NSString *refer;

/**
 最近一次点击事件的ID.内容为 "当前PageID|curActionDesc".
 */
@property (nonatomic, copy) NSString *curActionId;

/**
 最近一次点击事件的Token.内容为"A+UTDID+点击事件时间戳(单位ms)"
 */
@property (nonatomic, copy) NSString *curActionToken;

/**
 最近一次点击事件的描述信息.格式为控件的actionName属性值或控件的处理函数名.
 */
@property (nonatomic, copy) NSString *curActionDesc;

/**
 在MobileRuntime中设置.标示本次App启动(包含后台回前台)的来源.
 该值可能为Push消息的Id,scheme唤起时的tagid.或为空.
 */
@property (nonatomic, readonly) NSString *sourceId;

@end
#endif //WIP
