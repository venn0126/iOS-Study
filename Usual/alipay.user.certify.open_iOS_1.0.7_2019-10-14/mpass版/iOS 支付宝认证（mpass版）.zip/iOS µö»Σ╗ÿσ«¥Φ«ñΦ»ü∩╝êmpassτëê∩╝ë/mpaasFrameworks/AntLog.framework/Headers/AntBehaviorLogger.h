//
//  AntBehaviorLogger.h
//  AntLog
//
//  Created by 卡迩 on 2017/1/29.
//  Copyright © 2017年 Alipay. All rights reserved.
//

#ifndef WIP
#ifndef AntBehaviorLogger_h
#define AntBehaviorLogger_h

#import "AntLogger.h"
#import "AntBehavior.h"

/**
 行为日志Logger接口
 */
@protocol AntBehaviorLogger <AntLogger>

@required
#pragma mark - Manual
/**
 点击事件

 @param behavior 事件对应的日志模型
 */
- (void)click:(AntBehavior *)behavior;

/**
 页面打开事件

 @param behavior 事件对应的日志模型
 */
- (void)openPage:(AntBehavior *)behavior;

/**
 长按事件

 @param behavior 事件对应的日志模型
 */
- (void)longClick:(AntBehavior *)behavior;

/**
 提交事件

 @param behavior 事件对应的日志模型
 */
- (void)submit:(AntBehavior *)behavior;

/**
 滑动事件

 @param behavior 事件对应的日志模型
 */
- (void)slide:(AntBehavior *)behavior;

#pragma mark - Auto
/**
 自动页面打开事件

 @param behavior 事件对应的日志模型
 */
- (void)autoOpenPage:(AntBehavior *)behavior;

/**
 自动点击事件

 @param behavior 事件对应的日志模型
 */
- (void)autoClick:(AntBehavior *)behavior;

/**
 自动特殊事件

 @param behavior 事件对应的日志模型
 */
- (void)autoEvent:(AntBehavior *)behavior;

#pragma mark - General
/**
 通用事件

 @param behavior 事件对应的日志模型
 */
- (void)logEvent:(AntBehavior *)behavior;

@end

#ifdef __cplusplus
extern "C" {
#endif
    
    /**
     获取行为日志Logger

     @return 行为日志Logger实例
     */
    id<AntBehaviorLogger> AntBehaviorLoggerGet();
    
#ifdef __cplusplus
}
#endif


#endif /* AntBehaviorLogger_h */
#endif //WIP
