//
//  APBAlertController.h
//  BioAuthEngine
//
//  Created by yukun.tyk on 3/2/16.
//  Copyright © 2016 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>


extern NSString *const kAlertViewAppear;
extern NSString *const kAlertViewDisappear;


@interface APBAlertController : UIAlertController

@end
