//
//  ZolozIdentityPublicApi.h
//  ZolozIdentityManager
//
//  Created by richard on 22/11/2017.
//  Copyright © 2017 Alipay. All rights reserved.
//

#ifndef ZolozIdentityPublicApi_h
#define ZolozIdentityPublicApi_h

#import <ZolozIdentityManager/ZolozIdentityManager.h>
#import <ZolozIdentityManager/ZIMResponse.h>
#import <ZolozIdentityManager/ZolozSdk.h>

#endif /* ZolozIdentityPublicApi_h */
