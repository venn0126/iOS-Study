//
//  ZolozSdk.h
//  ZolozIdentityManager
//
//  Created by richard on 22/11/2017.
//  Copyright © 2017 Alipay. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZolozSdk : NSObject

+ (void)init;

@end
